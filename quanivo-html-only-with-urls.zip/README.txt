QUANIVO SITE EXPORT - SPLIT ARCHIVE
====================================

This export is split into multiple parts due to file size limits.

PARTS:
------
Part 1: HTML pages only (all 35+ pages including blog posts)
Part 2: Blog images (53 images from blog posts)
Part 3a: Site images - Hero sliders & gallery
Part 3b1b: Site images - Hyperbaric equipment (set 1)
Part 3b2: Site images - Hyperbaric equipment (set 2)
Part 4: Site images - Hyperbaric hardshell & walled chambers
Part 5: Site images - Massage chairs & infrared panels
Part 6a1a: Site images - Massage chairs (small)
Part 6a2: Site images - Recliners & product shots
Part 6b: Site images - Recliners & vacuum treadmills
Part 7: Site images - Valera equipment & vacuum treadmills

MISSING FILES (too large for Telegram):
---------------------------------------
- hero-wellness-pod.jpeg (14MB)
- pod-session.jpeg (6.2MB)

You can download these directly from the live site if needed:
https://quanivo-site.vercel.app/images/hero-wellness-pod.jpeg
https://quanivo-site.vercel.app/images/pod-session.jpeg

TO RECONSTRUCT:
---------------
1. Extract all parts to the same folder
2. Move images from subfolders to /images/ folder
3. The HTML files will link to images correctly

TOTAL:
------
- 35 HTML pages (15 main + 20 blog posts)
- 129 images (131 total minus 2 large ones)
